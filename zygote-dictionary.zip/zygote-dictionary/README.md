# Zygote Dictionary — *New era, New Dictionary*
Fuse two or more real English words into a brand-new one, write your own meaning, publish it.

**Files:** `index.html`, `style.css`, `app.js`, `data/words.json` (~57k public-domain Webster's entries, one-liners), `data/community.json` (shared coined words), `tools/` (Python helpers).

**Deploy:** push the whole folder to a GitHub repo, enable Pages. Locally: `python -m http.server`, open http://localhost:8000 (fetch needs http, not file://).

**How publishing works:** GitHub Pages is static, so a published word is saved in the player's browser (their ownership) and shown under *Newly constructed*. To make words visible to everyone: players use *Copy my words as JSON*, you run `python tools/merge_community.py submission.json`, then commit `data/community.json`. For instant global publishing, swap `save()`/`fetch` in `app.js` for a free backend (e.g. Firebase or Supabase).

**Rebuild the dictionary:** `python tools/build_dictionary.py dictionary_compact.json` (source: github.com/matthewreagan/WebstersEnglishDictionary).
