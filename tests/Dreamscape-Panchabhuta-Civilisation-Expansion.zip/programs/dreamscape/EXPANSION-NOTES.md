# Dreamscape: Panchabhūta — Civilisation Expansion

This package is a drop-in replacement for the repository folder:

`programs/dreamscape/`

It preserves the existing game engine, Panchabhūta planets, economy, Tamasi storyline, diplomacy, Dyson progression, planetary science, 3D engine and save system. New systems are added as lightweight browser-side JavaScript and Three.js geometry. No paid API, external AI model, server, account system or GPU service is introduced.

## Main additions

- **Planned capital city:** wider avenues, continuous pedestrian footpaths, raised curbs, central civic junctions, additional roundabouts, office towers, shops, private apartments, residential mansions, gardens and royal transport vehicles.
- **Capital services:** Mahal inspection panels for royal gardens, treasury, ministers' residence and workers' residence. Entering the Sabha begins the existing court proceedings.
- **Spaceport network:** a terminal and launch pads in each planetary capital, a Space Agency command centre, reusable Pushpak passenger service and a 20–50 passenger capacity progression.
- **Secure solar field:** a fenced, dedicated solar collection district. Its in-game access check is a fictional permission mechanic, not a real biometric/fingerprint reader. The field contributes energy when Dyson infrastructure is active.
- **Defence quarter:** high-level fictional orbital surveillance, warning, shield, protected communications and civilian emergency-readiness systems. No real-world weapon construction or operating instructions are represented.
- **Continents:** deterministic continental landforms, named regions, survey actions, resource profiles and regional settlement metadata.
- **Expandable atlas:** zoom, pan, frontier survey, continent survey, up to twelve additional cities per planet, and designated port cities.
- **Natural moons:** three named moons per planet, orbit rendering and scientific expedition missions.
- **Navigation:** a capital navigator with guided routes to the Mahal, spaceport, offices and solar field, plus an on-screen movement pad for touch devices.
- **Adaptive chronicle:** story events respond to pollution, biosphere, Dharma, settlement growth, spaceport development, Dyson-linked solar collection, defence readiness, moon missions and continental surveys.

## Files changed or added

- `index.html` — loads the new systems and updates the walking hint.
- `style.css` — responsive touch controls and capital navigation UI.
- `extras.js` — expanded terrain/continental landforms, larger walkable world and passenger capacity display.
- `city.js` — city roads, footpaths, junctions, civic districts, port, solar field, residences and royal transport.
- `maps.js` — expandable planetary atlas, continental survey and expanded settlement management.
- `orbit.js` — natural moon rendering and expedition entry point.
- `guide.js` — updated game instructions and new system explanations.
- `civilisation.js` — new capital, Mahal, spaceport, solar-field, defence, transport, moon-expedition and touch-navigation systems.
- `lore.js` — stat-driven chronicle events and passive regional/Dyson-linked resource effects.

All other original Dreamscape files and the archived alternate versions are retained in this package.

## Install

1. Back up your current `programs/dreamscape/` folder.
2. Extract this ZIP at the repository root, preserving the `programs/dreamscape/` path.
3. Commit and push the replacement folder to the `projects` branch.
4. Open `programs/dreamscape/index.html` through GitHub Pages after deployment.

Do not upload only `index.html`: the game is modular and requires the complete folder, including `three.min.js` and every JavaScript module.

## Compatibility and verification

- Existing localStorage save data remains under the same save key; new properties are added lazily so older saves can continue.
- All top-level Dreamscape JavaScript files pass `node --check` syntax validation.
- Script references in the main HTML were checked against the package contents.
- A full interactive WebGL/browser playtest could not be completed in this execution environment because Chromium's WebGL context failed to initialise. Please test the game on the target browser/device before publishing.

## Known design boundaries

- Fingerprint access is simulated as a game permission check; browsers cannot read a real fingerprint through this page.
- City navigation uses guided avenue waypoints rather than a full general-purpose pathfinding engine.
- Moons and their scientific expeditions are strategic/educational fictional models, not ephemeris-accurate astronomical simulations.
- Continental landforms are deterministic procedural terrain, not real planetary elevation datasets.
